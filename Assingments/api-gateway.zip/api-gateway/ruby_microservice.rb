# ruby_microservice.rb
require 'sinatra'

get '/' do
  'Hello from Ruby microservice!'
end
